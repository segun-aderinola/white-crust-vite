## Contributing

- Fork it from [main branch](https://github.com/jesvijonathan/JOS-Animation-Library)
- Add your useful feature or fix a bug
- Create a pull request

---

- Found a bug ? [open an issue]()
- Report a bug as an issue with more details

---

- Have a feature request ? [open an issue]()
- Report a feature request as an issue with more details
- Refer templates presets for more info

---
