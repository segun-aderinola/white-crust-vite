### Check out the repository for more information<br>

[README.md](https://jesvijonathan.github.io/JOS-Animation-Library)
