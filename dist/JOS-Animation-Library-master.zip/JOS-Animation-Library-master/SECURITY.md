# Security Policy

## Supported Versions

I would reccomend the latest version of JOS at any given point of the time line, the only reason to use an older version of the project would probably be to make use of an discontinued feature which is not available in the latest version.
If a feature is discontinued, it's probably because of vulnerabillities or any other deprecated factor and would not recommend it's use for too long.

| Version | Supported          |
| ------- | ------------------ |
| 0.9.x   | :white_check_mark: |
| 0.8.x   | :white_check_mark: |
| 0.7.x   | :white_check_mark: |
| 0.6.x   | :white_check_mark: |
| 0.5.x   | :x:                |
| < 0.3.0 | :x:                |

## Reporting a Vulnerability

If any vulnerability found, please open an issue with critical label and create a pull request if you have the fix for the issue.

patches and updates regarding security/vulnerabilities are top priority and will be patched as soon as possible from the day the issue is opened
